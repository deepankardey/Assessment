# HibernateApp
Hibernate Basic App
