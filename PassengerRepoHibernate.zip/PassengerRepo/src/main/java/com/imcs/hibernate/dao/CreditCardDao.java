package com.imcs.hibernate.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.imcs.hibernate.entity.CreditCard;
import com.imcs.hibernate.interfaces.CreditCardDaoInterface;
import com.imcs.hibernate.utils.HibernateUtil;

public class CreditCardDao implements CreditCardDaoInterface {
	
	public boolean addCreditCard(CreditCard creditCard){
		boolean added = false;
		Session session  = getSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.save(creditCard);
			transaction.commit();
			added = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return added;
	}

	public CreditCard loadCreditCard(int id){
		Session session = null;
		CreditCard creditCard = null;
		try {
			session = getSession();
			creditCard = (CreditCard)session.get(CreditCard.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return creditCard;
	}

	public boolean updateCreditCard(CreditCard creditCard){
		boolean updated = false;
		Session session = getSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.update(creditCard);
			transaction.commit();
			updated = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return updated;
	}

	public boolean deleteCreditCard(int id){
		boolean deleted = false;
		Session session = getSession();
		Transaction transaction = session.beginTransaction();
		try {
			CreditCard creditCard = (CreditCard)session.get(CreditCard.class, id);
			session.delete(creditCard);
			transaction.commit();
			deleted = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return deleted;
	}
	

	@Override
	public List<CreditCard> loadAllCreditCard(){
		Session session = null;
		Query query = null;
		try {
			session = getSession();
			query = session.createQuery("FROM CreditCard");
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			return query.list();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return query.list();
	}

	private Session getSession() {
		return HibernateUtil.buildSessionFactory().openSession();
	}
}
