package com.imcs.hibernate.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.imcs.hibernate.entity.PassengerProfile;
import com.imcs.hibernate.interfaces.PassengerDaoInterface;
import com.imcs.hibernate.utils.HibernateUtil;

import trng.imcs.hib.excp.CustomException;

public class PassengerDao implements PassengerDaoInterface {
	
	public boolean addPassenger(PassengerProfile customer) throws CustomException {
		boolean added = false;
		Session session  = getSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.save(customer);
			transaction.commit();
			added = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return added;
	}

	public PassengerProfile loadPassenger(int id) throws CustomException {
		Session session = null;
		PassengerProfile passenger = null;
		try {
			session = getSession();
			passenger = (PassengerProfile)session.get(PassengerProfile.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return passenger;
	}

	public boolean updatePassenger(PassengerProfile customer) throws CustomException {
		boolean updated = false;
		Session session = getSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.update(customer);
			transaction.commit();
			updated = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return updated;
	}

	public boolean deletePassenger(int id) throws CustomException {
		boolean deleted = false;
		Session session = getSession();
		Transaction transaction = session.beginTransaction();
		try {
			PassengerProfile customer = (PassengerProfile)session.get(PassengerProfile.class, id);
			session.delete(customer);
			transaction.commit();
			deleted = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return deleted;
	}
	

	@Override
	public List<PassengerProfile> loadAllPassengers() throws CustomException {
		Session session = null;
		Query query = null;
		try {
			session = getSession();
			query = session.createQuery("FROM PassengerProfile");
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			return query.list();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(session!=null)
				session.close();
		}
		return query.list();
	}

	private Session getSession() {
		return HibernateUtil.buildSessionFactory().openSession();
	}
}
