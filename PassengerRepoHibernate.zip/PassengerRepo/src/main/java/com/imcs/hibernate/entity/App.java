package com.imcs.hibernate.entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.imcs.hibernate.utils.HibernateUtil;

public class App {
	public static void main(String[] args) {
		
		Session session = HibernateUtil.buildSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		PassengerProfile passenger = new PassengerProfile();
		passenger.setPassword("order 1");
		passenger.setFirstName("deepankar");
		passenger.setLastName("dey");
		passenger.setAddress("1145 oregon ave");
		passenger.setTelephoneNumber("4098128711");
		passenger.setEmail("deepankar@gmail.com");
		CreditCard creditCard = new CreditCard();
		creditCard.setCardNumber("1234567890");
		creditCard.setCardType("Credit");
		creditCard.setExpirationMonth(12);
		creditCard.setExpirationYear(2020);
		creditCard.setPassengerProfile(passenger);
		passenger.setCreditCard(creditCard);
		session.save(passenger);
		transaction.commit();
		
		
	}
}
