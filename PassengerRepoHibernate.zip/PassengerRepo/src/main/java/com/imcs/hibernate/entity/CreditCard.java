package com.imcs.hibernate.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="credit_card_details")
public class CreditCard {
	
	@Id
	@Column(name="card_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name="card_number",unique = true , nullable=false)
	private String cardNumber;

	@Column(name="card_type",unique = true , nullable=false)
	private String cardType;
	
	@Column(name="expiration_month",unique = true , nullable=false)
	private Integer expirationMonth;
	
	@Column(name="expiration_year",unique = true , nullable=false)
	private Integer expirationYear;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="profile_id")
	private PassengerProfile passengerProfile;
	
	public CreditCard() {
		super();
	}

	public CreditCard(String cardNumber, String cardType, Integer expirationMonth, Integer expirationYear,
			PassengerProfile passengerProfile) {
		super();
		this.cardNumber = cardNumber;
		this.cardType = cardType;
		this.expirationMonth = expirationMonth;
		this.expirationYear = expirationYear;
		this.passengerProfile = passengerProfile;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public Integer getExpirationMonth() {
		return expirationMonth;
	}

	public void setExpirationMonth(Integer expirationMonth) {
		this.expirationMonth = expirationMonth;
	}

	public Integer getExpirationYear() {
		return expirationYear;
	}

	public void setExpirationYear(Integer expirationYear) {
		this.expirationYear = expirationYear;
	}

	public PassengerProfile getPassengerProfile() {
		return passengerProfile;
	}

	public void setPassengerProfile(PassengerProfile passengerProfile) {
		this.passengerProfile = passengerProfile;
	}

	@Override
	public String toString() {
		return "CreditCard [cardNumber=" + cardNumber + ", cardType=" + cardType + ", expirationMonth="
				+ expirationMonth + ", expirationYear=" + expirationYear + ", passengerProfile=" + passengerProfile
				+ "]";
	}
	
}
