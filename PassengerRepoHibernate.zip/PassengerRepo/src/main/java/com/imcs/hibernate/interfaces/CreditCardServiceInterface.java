package com.imcs.hibernate.interfaces;

import java.util.List;

import com.imcs.hibernate.entity.CreditCard;

public interface CreditCardServiceInterface {

	public boolean addCreditCard(CreditCard creditCard);
	public CreditCard loadCreditCard(int id);
	public boolean updateCreditCard(CreditCard creditCard);
	public boolean deleteCreditCard(int id);
	public List<CreditCard> loadAllCreditCard();
}
