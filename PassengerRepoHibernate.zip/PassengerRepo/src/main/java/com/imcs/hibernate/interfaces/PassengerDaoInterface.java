package com.imcs.hibernate.interfaces;

import java.util.List;

import com.imcs.hibernate.entity.PassengerProfile;

import trng.imcs.hib.excp.CustomException;

public interface PassengerDaoInterface {
	public boolean addPassenger(PassengerProfile passenger) throws CustomException;
	public PassengerProfile loadPassenger(int id) throws CustomException;
	public boolean updatePassenger(PassengerProfile passenger) throws CustomException;
	public boolean deletePassenger(int id) throws CustomException;
	public List<PassengerProfile> loadAllPassengers()throws CustomException;
}
