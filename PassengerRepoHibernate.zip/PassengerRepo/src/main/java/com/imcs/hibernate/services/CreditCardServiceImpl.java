package com.imcs.hibernate.services;

import java.util.List;

import com.imcs.hibernate.dao.CreditCardDao;
import com.imcs.hibernate.entity.CreditCard;
import com.imcs.hibernate.interfaces.CreditCardDaoInterface;
import com.imcs.hibernate.interfaces.CreditCardServiceInterface;

import trng.imcs.hib.excp.CustomException;

public class CreditCardServiceImpl implements CreditCardServiceInterface {
	
	CreditCardDaoInterface creditCardDao = new CreditCardDao();
	
	public boolean addCreditCard(CreditCard creditCard) throws CustomException {
		return creditCardDao.addCreditCard(creditCard);
	}

	public CreditCard loadCreditCard(int id) throws CustomException {
		return creditCardDao.loadCreditCard(id);
	}

	public boolean updateCreditCard(CreditCard creditCard) throws CustomException {
		return creditCardDao.updateCreditCard(creditCard);
	}

	public boolean deleteCreditCard(int id) throws CustomException {
		return creditCardDao.deleteCreditCard(id);
	}

	public List<CreditCard> loadAllCreditCard() throws CustomException {
		return creditCardDao.loadAllCreditCard();
	}

}
