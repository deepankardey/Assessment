package com.imcs.hibernate.services;

import java.util.List;

import com.imcs.hibernate.dao.PassengerDao;
import com.imcs.hibernate.entity.PassengerProfile;
import com.imcs.hibernate.interfaces.PassengerDaoInterface;
import com.imcs.hibernate.interfaces.PassengerServiceInterface;

import trng.imcs.hib.excp.CustomException;

public class PassengerProfileServiceImpl implements PassengerServiceInterface {
	
	PassengerDaoInterface passengerProfileDao = new PassengerDao();
	
	public boolean addPassenger(PassengerProfile passengerProfile) throws CustomException {
		return passengerProfileDao.addPassenger(passengerProfile);
	}

	public PassengerProfile loadPassenger(int id) throws CustomException {
		return passengerProfileDao.loadPassenger(id);
	}

	public boolean updatePassenger(PassengerProfile passengerProfile) throws CustomException {
		return passengerProfileDao.updatePassenger(passengerProfile);
	}

	public boolean deletePassenger(int id) throws CustomException {
		return passengerProfileDao.deletePassenger(id);
	}

	public List<PassengerProfile> loadAllPassenger() throws CustomException {
		return passengerProfileDao.loadAllPassengers();
	}

}
