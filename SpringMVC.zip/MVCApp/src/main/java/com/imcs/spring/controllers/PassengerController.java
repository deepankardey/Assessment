package com.imcs.spring.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.imcs.spring.dao.PassengerDao;
import com.imcs.spring.entity.PassengerProfile;

import trng.imcs.hib.excp.CustomException;

@Controller
public class PassengerController {
	@Autowired
	PassengerDao passengerDao;
	
	@PostMapping("/addPassenger")
	public String addCustomer(@ModelAttribute(value="passenger") @Valid PassengerProfile passenger, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			System.out.println(bindingResult.getNestedPath());
			return "AddPassenger";
		} else {
			model.addAttribute("passenger", new PassengerProfile());
			if(passenger.getProfileId()!=null) {
				try {
					passengerDao.updatePassenger(passenger);
					model.addAttribute("message", "Customer updated Successfully");
				} catch (Exception e) {
					model.addAttribute("message", "Exception Occured");
					e.printStackTrace();
				}
			}
			else {
				try {
					passengerDao.addPassenger(passenger);
					model.addAttribute("message", "Customer added Successfully");
				} catch (CustomException e) {
					model.addAttribute("message", "Exception Occured");
					e.printStackTrace();
				}
			}
			return "Success";
		}
	}
	
	@GetMapping("/getPassenger")
	public String getCustomers(@ModelAttribute(value="passenger") @Valid PassengerProfile passenger,Model model) {
		List<PassengerProfile> list = null;
		if(passenger.getProfileId()!=null) {
			list = new ArrayList<PassengerProfile>();
			passenger = passengerDao.loadPassenger(passenger.getProfileId());
			list.add(passenger);
		}
		else
			list = passengerDao.loadAllPassengers();
		model.addAttribute("passengerList", list);
		return "ShowPassenger";
	}
	
	@GetMapping(value = "/updatePassenger/{id}")
	public String updateCustomers(@PathVariable("id") int id,Model model) {
		PassengerProfile passenger = passengerDao.loadPassenger(id);
		List<PassengerProfile> list = new ArrayList<PassengerProfile>();
		list.add(passenger);
		model.addAttribute("passenger", passenger);
		model.addAttribute("passengerList", list);
		return "UpdatePassenger";
	}
	
	@GetMapping(value = "/deletePassenger/{id}")
	public String deletePassenger(@PathVariable("id") int id,Model model) {
		Boolean deleted = passengerDao.deletePassenger(id);
		if(deleted) {
			model.addAttribute("message", "Passenger deleted Successfully");
			return "Success";
		}
		else {
			model.addAttribute("message", "Error occured while deleted Passenger");
			return "Error";
		}
	}
}
