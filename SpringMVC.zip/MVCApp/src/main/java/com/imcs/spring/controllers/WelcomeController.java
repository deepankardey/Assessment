package com.imcs.spring.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.imcs.spring.entity.PassengerProfile;

@Controller
public class WelcomeController {

	@GetMapping("/")	
	public String getLoginPage() {
		return "Home";
	}
	
	@GetMapping("/home")
	public String showHomePage() {
		return "Home";
	}
	
	@GetMapping("/showPassenger")
	public String showCustomerPage(Model model) {
		model.addAttribute("passenger", new PassengerProfile());
		return "ShowPassenger";
	}
	
	@GetMapping("/addPassenger")
	public String addCustomerPage(Model model) {
		model.addAttribute("passenger", new PassengerProfile());
		return "AddPassenger";
	}
}
