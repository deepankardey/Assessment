package com.imcs.spring.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.imcs.spring.entity.PassengerProfile;

import trng.imcs.hib.excp.CustomException;

@Repository
public class PassengerDao{
	
	@Autowired
	Session session;
	
	public boolean addPassenger(PassengerProfile passenger) throws CustomException {
		boolean added = false;
		Transaction transaction = session.beginTransaction();
		try {
			session.save(passenger);
			transaction.commit();
			added = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
		}
		return added;
	}

	public PassengerProfile loadPassenger(int id) throws CustomException {
		PassengerProfile passenger = null;
		try {
			passenger = (PassengerProfile)session.get(PassengerProfile.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
		}
		return passenger;
	}

	public boolean updatePassenger(PassengerProfile passenger) throws CustomException {
		boolean updated = false;
		Transaction transaction = session.beginTransaction();
		try {
			session.merge(passenger);
			transaction.commit();
			updated = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
		}
		return updated;
	}

	public boolean deletePassenger(int id) throws CustomException {
		boolean deleted = false;
		Transaction transaction = session.beginTransaction();
		try {
			PassengerProfile customer = (PassengerProfile)session.get(PassengerProfile.class, id);
			session.delete(customer);
			transaction.commit();
			deleted = true;
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
		}
		return deleted;
	}
	

	public List<PassengerProfile> loadAllPassengers(){
		Query query = null;
		try {
			query = session.createQuery("FROM PassengerProfile");
			query.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
		}
		return query.list();
	}

}
